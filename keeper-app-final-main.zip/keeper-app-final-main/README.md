A Note Keeping App Designed with a User-Friendly Interface.
Create short,daily use notes,with a user-friendly Interface.
